package ClasesParcial;

public interface Alquiler {
    public int calcularAlquileres(int precioBase, int mesesAlquilado);
    public void aumentarAlquileres(int porcentaje); // un porcentaje del 1% - 100%

}
